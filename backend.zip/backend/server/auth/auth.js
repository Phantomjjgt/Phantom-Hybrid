
module.exports = {
    signingKey: '',
    clientId: '',
    clientSecret: '',
    clientService: ''
}