const util = require('../util'),
express = require('express'),
axios = require('axios')
const fs = require("fs");
const { application } = require('express')

let app = express()

//they moved news to this endpoint a while ago
 
 // news
 app.get('/api/v1/fortnite-br/surfaces/motd/target', (req, res) => {
      res.json(require(`../Json_Files/news.json`));
      console.log("Requested for News")
      });

// fn game
 app.get("/content/api/pages/fortnite-game/", (req,res) => {
let rawdata = fs.readFileSync(`./Json_Files/fortnite-game.json`);
let fortnitegame = JSON.parse(rawdata);
  const fileName1 = `../Json_Files/localization.json`;
const file1 = require(fileName1);
      const fileName = `../Json_Files/fortnite-game.json`;
const file = require(fileName);


    if(req.headers["accept-language"] == "en") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.en.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.en.body
    }
      else if(req.headers["accept-language"] == "ru") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.ru.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.ru.body
      }
      else if(req.headers["accept-language"] == "uk-UA") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.ua.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.ua.body
      }
           else if(req.headers["accept-language"] == "pt-BR") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.pt.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.pt.body
      }
      else if(req.headers["accept-language"] == "es") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.es.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.es.body
      }
      else if(req.headers["accept-language"] == "es-419") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.es.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.es.body
      }      
         else if(req.headers["accept-language"] == "fr") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.fr.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.fr.body
      }      
         else if(req.headers["accept-language"] == "ja") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.ja.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.ja.body
      }    
         else if(req.headers["accept-language"] == "de") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.de.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.de.body
      }   
         else if(req.headers["accept-language"] == "it") {
      file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.it.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.it.body
      }    
    else {
          file.emergencynoticev2.emergencynotices.emergencynotices[0].title = file1.emergencynoticev2.en.title
          file.emergencynoticev2.emergencynotices.emergencynotices[0].body = file1.emergencynoticev2.en.body
    }
    console.log(req.headers["accept-language"])
      res.json(file)
 console.log("Requested for fortnite-game")

  
  }) 

// shop

app.get('/fortnite/api/storefront/v2/catalog', (req, res) => {
	res.json(require(`../Json_Files/shop.json`));
      console.log("Requested for shop")
});


app.get('/content/api/pages/fortnite-game/media-events', async (req, res) => {

    axios.get('https://fortnitecontent-website-prod07.ol.epicgames.com/content/api/pages/fortnite-game/media-events')
    .then(response => {
        res.json(response.data)
    })
})

module.exports = app