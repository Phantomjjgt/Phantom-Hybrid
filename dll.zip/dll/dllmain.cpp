#include <Windows.h>
#include "curl.h"
#include <iostream>

using namespace std;

BOOL APIENTRY DllMain(HMODULE module, DWORD call_reason, LPVOID reserved) {

    if (call_reason != 1) 
        return 1;

    hookCurl();
    CreateThread(0, 0, (LPTHREAD_START_ROUTINE)hookCurl, 0, 0, 0);

    FILE* fDummy;
    AllocConsole();
    freopen_s(&fDummy, "CONIN$", "r", stdin);
    freopen_s(&fDummy, "CONOUT$", "w", stderr);
    freopen_s(&fDummy, "CONOUT$", "w", stdout);

    SetConsoleTitleA("NeoFN | Made By LeakerByDragon and Phantom");

    system("color 0B");

    printf("    _   __           _______   __   \n");
    printf("   / | / /__  ____  / ____/ | / /   \n");
    printf("  /  |/ / _ \\/ __ \\/ /_  /  |/ /  \n");
    printf(" / /|  /  __/ /_/ / __/ / /|  /     \n");
    printf("/_/ |_/\\___/\\____/_/   /_/ |_/    \n");

    printf("\n \n[=]Welcome to NeoFN \n");

    return 1;
}

